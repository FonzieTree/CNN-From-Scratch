import numpy as np
from numpy import *


np.random.seed(1)      
data=np.genfromtxt("train.csv",dtype = 'str',skip_header=0,delimiter = ',')
print(data.shape)